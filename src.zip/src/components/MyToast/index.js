import React from "react";
import { View, ActivityIndicator } from "react-native";
import { Color, Styles } from "@common";

export const MyToast = () => {
  return (
    <View style={Styles.lodarMainView}>
      
    </View>
  );
}
