// import * as types from './actionTypes';
export const API_REQUEST = 'API_REQUEST';
export const API_REQUEST_SUCCEEDED = 'API_REQUEST_SUCCEEDED';
export const API_REQUEST_FAILED = 'API_REQUEST_FAILED';

export function apiRequest(payload) {
  return {
    type: types.API_REQUEST,
    payload: payload
  }
}

export function apiRequestSucceeded(payload) {
  return {
    type: types.API_REQUEST_SUCCEEDED,
    payload: payload
  }
}

export function apiRequestFailed(payload) {
  return {
    type: types.API_REQUEST_FAILED,
    payload: payload
  }
}
