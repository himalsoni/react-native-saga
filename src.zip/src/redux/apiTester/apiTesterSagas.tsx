import {delay} from 'redux-saga';
import {call, put, takeEvery, takeLatest} from 'redux-saga/effects';
import axios from 'axios';
// import {API_REQUEST} from './apiTesteActions';
// import * as types from './actionTypes';

function* handleApiRequest(action) {
  try {
    const apiConfig = {
      method: 'post',
      url: 'https://jsonplaceholder.typicode.com/posts',
      data: {
        section_id: action.payload.section_id
      }
    };

    const response = yield call(axios, apiConfig);
    console.log(response);
    yield put({type: 'API_REQUEST_SUCCEEDED', payload: response.data });
  } catch (e) {
    console.log(e);
    yield put({type: 'API_REQUEST_FAILED', payload: e.message });
  }
}

export default function* watchApiRequest() {
  console.log('--watchApiRequest--')
  // yield [yield takeLatest('API_REQUEST', handleApiRequest)];
  yield takeEvery('API_REQUEST', handleApiRequest);
}
