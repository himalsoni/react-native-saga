import {delay} from 'redux-saga';
import {call, put, takeEvery} from 'redux-saga/effects';

export function* handleIncrementAsync() {
  console.log('--handleIncrementAsync--')
  yield delay(1000);
  // yield put({type: 'INCREMENT'});
}

export function* watchIncrementAsync() {
  alert('--watchIncrementAsync--')
  console.log('--watchIncrementAsync--');
  yield takeEvery('INCREMENT_ASYNC', handleIncrementAsync);
}
