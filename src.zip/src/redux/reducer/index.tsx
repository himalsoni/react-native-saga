import { combineReducers } from "redux";

import {reducer as counterReducer} from './counterReducer';
import {reducer as apiTesterReducer} from './apiTesterReducer';

const rootReducer = combineReducers({
  counter: counterReducer,
  apiTester: apiTesterReducer,
});

export default rootReducer;
