import {fork, all, call} from 'redux-saga/effects';

import {watchIncrementAsync} from './counter/counterSaga';
import {watchApiRequest} from './apiTester/apiTesterSagas';

export default function* rootSaga() {
  yield all([
    call(watchApiRequest),
    call(watchIncrementAsync)
  ])
}
