/**
 * Created for storing images of the application
 *
 * @format
 */

const Images = {
  // design: require("@images/icons/design.png"),
  // size: require("@images/icons/size.png"),
  // cutting: require("@images/icons/cutting.png"),
  // order: require("@images/icons/order.png"),
  // logout: require("@images/icons/logout.png"),
  // next_arrow: require("@images/icons/next_arrow.png"),
  // gallery: require("@images/icons/gallery.png"),
  // close: require("@images/icons/close.png"),
  // radio_active: require("@images/icons/radio_active.png"),
  // radio_inactive: require("@images/icons/radio_inactive.png"),
  // logo: require("@images/icons/logo.png"),
  // pen: require("@images/icons/pen.png"),
  // down_arrow: require("@images/icons/down_arrow.png"),
  //
  // signuplogo: require("@images/icons/signuplogo.png"),
  // signuptop: require("@images/icons/signuptop.png"),
  // eye_slash: require("@images/icons/eye_slash.png"),
  // back: require("@images/icons/back.png"),
  // search: require("@images/icons/search.png"),
  // home_active: require("@images/icons/home_active.png"),
  // home_inactive: require("@images/icons/home_inactive.png"),
  // activity_active: require("@images/icons/activity_active.png"),
  // add: require("@images/icons/add.png"),
  // activity_inactive: require("@images/icons/activity_inactive.png"),
  // notification_active: require("@images/icons/notification_active.png"),
  // notification_inactive: require("@images/icons/notification_inactive.png"),
  // profile_active: require("@images/icons/profile_active.png"),
  // profile_inactive: require("@images/icons/profile_inactive.png"),
  // plus: require("@images/icons/plus.png"),
  // heart: require("@images/icons/heart.png"),
  // heart_filled: require("@images/icons/heart_filled.png"),
  // green_rating: require("@images/icons/green_rating.png"),
  // offer_unchecked: require("@images/icons/offer_unchecked.png"),
  // offer_checked: require("@images/icons/offer_checked.png"),
  // placeholder_pic: require("@images/icons/placeholder_pic.png"),

  // camera: require("@images/icons/camera.png"),
  // tick_circle: require("@images/icons/tick_circle.png"),
  //
  // dc: require("@images/icons/dc.png"),

  // close: require("@images/icons/close.png"),
  // logo_horizontal: require("@images/icons/logo_horizontal.png"),
  // casuals: require("@images/icons/casuals.png"),
  // dresses: require("@images/icons/dresses.png"),
  // sort: require("@images/icons/sort.png"),
  // filter: require("@images/icons/filter.png"),
  // damaged: require("@images/icons/damaged.png"),
  // return: require("@images/icons/return.png"),
  // user: require("@images/icons/user.png"),
  // tab_rectangle: require("@images/icons/tab_rectangle.png"),
  // verified: require("@images/icons/verified.png"),
  // box: require("@images/icons/box.png"),
  // card: require("@images/icons/card.png"),
  // send: require("@images/icons/send.png"),
  // menu: require("@images/icons/menu.png"),
  // savedcards: require("@images/icons/savedcards.png"),
};

export default Images;
